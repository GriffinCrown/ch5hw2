﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FileWriter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                int txtNumber = 0;
                int number = int.Parse(txtNumber.ToString());

                //write code that assigns the value in the textbox to an Integer variable

                if (number <= 1) /* write code that validates whether or not the data entered in the textbox is greater than or equal to 1 */
                {

                    try
                    {


                        SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                        saveFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                        saveFileDialog1.FilterIndex = 1;
                        saveFileDialog1.CheckFileExists = false;
                        saveFileDialog1.InitialDirectory = Application.StartupPath; //complete the code for the InitialDirectory property
                        saveFileDialog1.RestoreDirectory = true;

                        if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                        {
                            string strFileName = saveFileDialog1.FileName;
                            FileStream fileOut = new FileStream(strFileName, FileMode.Create);
                            StreamWriter writer = new StreamWriter(fileOut);

                            //Create an object of the Random class
                            Random random = new Random();
                            int randomNumber = 0;

                                for (int i = 0; i < number; i++) /* program a loop condition that repeats a number of times equal to the number entered in the textbox */
                            {
                                int n = random.Next(1, 100);
                                writer.WriteLine(randomNumber.ToString()); //write code that generates a random number and writes it into the .txt file
                            }
                            writer.Close(); //close the writer object
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Error saving the changes to the data file.",
                                "Error Saving Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please enter an integer greater than zero");
                }
            }

            
            catch
            {
                MessageBox.Show("Please enter an integer greater than zero");
            }

            }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
